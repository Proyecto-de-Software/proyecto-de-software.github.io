import { createApp } from 'vue'
import App from './Hello.vue'

createApp(App).mount('#app')
