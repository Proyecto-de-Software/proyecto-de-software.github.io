<template>
  <div class="ruta1">
    <h1>Ruta 1</h1>
      <ul>
      <li v-for="(location, index) in locations" :key="index">
        {{ location }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      locations: [1,2,3,4],
      errors: []
    }
  }
}
</script>