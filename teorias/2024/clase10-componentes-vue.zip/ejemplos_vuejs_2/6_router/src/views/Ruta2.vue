<template>
  <div class="ruta2">
    <h1>Ruta 2</h1>
    <h3>{{ parametro }}</h3>
  </div>
</template>
<script>
export default {
  props: {
    parametro: String
  }
}
</script>