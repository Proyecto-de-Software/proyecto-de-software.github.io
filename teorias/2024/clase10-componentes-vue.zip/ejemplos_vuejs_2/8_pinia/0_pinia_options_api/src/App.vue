<script>
  import MyComponent from '@/components/MyComponent.vue'
  import { mapState } from 'pinia'
  import { useCounterPiniaStore } from '@/stores/test'

  // https://pinia.vuejs.org/cookbook/options-api.html
  
    export default {
      components: {
        MyComponent
      },
      computed: {
          ...mapState(useCounterPiniaStore, ['count','randomizeCounter', 'increment']),
      },
    }
</script>

<template>
  <h1>Counter: {{ count }} <button @click="increment()">+</button></h1>
  <ol>
    <li><MyComponent /></li>
    <li><MyComponent /></li>
    <li><MyComponent /></li>
  </ol>
</template>