# Vue 3 example with Pinia

## Usage

```sh
yarn
yarn dev
```

[Open the local server](http://localhost:3000) and inspect using the [Vue Devtools beta](https://chrome.google.com/webstore/detail/vuejs-devtools/ljjemllljcmogpfapbkkighbhhppjdbg?hl=en).

## Related

- [Pinia 🍍](https://github.com/posva/pinia)
