<template>
    <div>
      <h1> User  </h1>
      <p> Usuario logueado: {{ user.name }} <span v-if="user.isAdmin">( Administrador!!! )</span></p>
    </div>
</template>
  
<script>
    // Usando Composition API => https://vuejs.org/api/composition-api-setup.html

    import { useUserStore } from '../stores/user'
    export default {
    setup() {
        const user = useUserStore()

        return { user }
    },
    }
</script>

