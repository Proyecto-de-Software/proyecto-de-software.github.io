# Ejemplos Sesiones - pyMysql - ORM - SQLi - XSS

## Primero hay que levantar el servicio de DB:

* Pueden usar el propio o levantar todo con Docker: 
- docker-compose up -d
Quedaría:
- Phpmyadmin: http://localhost/
- MariaDB: localhost:3306

## Cargar dump de DB para ejemplos: 
- dump/db_dump.sql

## Crear el virtualenv e instalar las dependencias de los ejemplos
- virtualenv -p python3 venv
- . venv/bin/activate
- pip install -r app_template/requirements.txt

## Dentro de los ejemplos tenemos:

- Script para decodificar sesiones de flask: flask-session-cookie-manager 
    python flask_session_cookie_manager3.py decode  -c COOKIE

- Ejemplo de pymysql: eje_pymysql.py

- App con todos los demás ejemplos dentro de **app_template**. 
    python run.py
    Levanta todo en http://localhost:5000/
