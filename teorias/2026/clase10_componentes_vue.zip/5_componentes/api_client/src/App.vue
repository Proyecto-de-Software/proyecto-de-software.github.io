<script setup>
import ApiClient from './components/ApiClient.vue'
</script>

<template>
  <div id="app">
    <ApiClient />
  </div>
</template>
