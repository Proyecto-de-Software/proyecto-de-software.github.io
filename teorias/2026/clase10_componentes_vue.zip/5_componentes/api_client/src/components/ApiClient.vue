<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const locations = ref([])
const errors = ref([])

// Obtiene las provincias cuando el componente se monta.
onMounted(async () => {
  try {
    const response = await axios.get(
      'https://apis.datos.gob.ar/georef/api/provincias'
    )
    // Axios parsea automáticamente las respuestas JSON.
    locations.value = response.data.provincias
  } catch (e) {
    errors.value.push(e)
  }
})
</script>

<template>
  <div>
    <h1>Provincias:</h1>
    <ul v-if="locations.length">
      <li v-for="location in locations" :key="location.id">
        <strong>{{ location.id }}</strong> - {{ location.nombre }}
      </li>
    </ul>

    <ul v-if="errors.length">
      <li v-for="(error, index) in errors" :key="index">
        {{ error.message }}
      </li>
    </ul>
  </div>
</template>
