<script setup>
import { ref } from 'vue'

const greeting = ref('Hola')
</script>

<template>
  <p>{{ greeting }} World!</p>
</template>

<style scoped>
p {
  font-size: 2em;
  text-align: center;
}
</style>
