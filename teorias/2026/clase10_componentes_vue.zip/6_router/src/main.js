import { createApp } from 'vue'
import App from './App.vue'
import router from './router' // Router being imported

createApp(App).use(router).mount('#app')
