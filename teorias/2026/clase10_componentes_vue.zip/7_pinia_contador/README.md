# Pinia: múltiples contadores

Ejemplo con Vite + Vue 3 + Pinia (setup store). Varios componentes `Counter`
comparten el mismo estado global a través del store `useCounterStore`.

## Ejecutar

```sh
npm install
npm run dev
```

## Build de producción

```sh
npm run build
npm run preview
```

Documentación: https://pinia.vuejs.org/
