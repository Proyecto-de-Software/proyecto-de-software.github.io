<script setup>
import { storeToRefs } from 'pinia'
import { useCounterStore } from './stores/counter'
import Counter from './components/Counter.vue'

const store = useCounterStore()
const { count, double } = storeToRefs(store)
</script>

<template>
  <div id="app">
    <h1>Estado global: count = {{ count }} (doble = {{ double }})</h1>

    <img alt="Vue logo" src="./assets/logo.png" />
    <table width="80%" align="center">
      <tbody>
        <tr>
          <td><Counter msg="Contador 1" :num="1" /></td>
          <td><Counter msg="Contador 2" :num="2" /></td>
          <td><Counter msg="Contador 3" :num="3" /></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
