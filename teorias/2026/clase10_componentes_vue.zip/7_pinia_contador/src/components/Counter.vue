<script setup>
import { storeToRefs } from 'pinia'
import { useCounterStore } from '../stores/counter'

const props = defineProps({ msg: String, num: Number })

const store = useCounterStore()
// storeToRefs mantiene la reactividad al desestructurar el estado
const { count } = storeToRefs(store)
// las actions se desestructuran directamente del store
const { increment, decrement } = store
</script>

<template>
  <div class="counter">
    <h2>{{ msg }}</h2>
    <p>count = {{ count }}</p>
    <p>
      <button @click="increment(props.num)">+{{ num }}</button>
      <button @click="decrement(props.num)">-{{ num }}</button>
    </p>
  </div>
</template>

<style scoped>
button {
  margin: 0 5px;
}
</style>
