import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

// Setup store: ref() = state, computed() = getters, function() = actions
export const useCounterStore = defineStore('counter', () => {
  const count = ref(0)
  const double = computed(() => count.value * 2)

  function increment(amount = 1) {
    count.value += amount
  }

  function decrement(amount = 1) {
    count.value -= amount
  }

  return { count, double, increment, decrement }
})
