# Options API vs Composition API

Ejemplo con Vite + Vue 3.

- `src/components/ContadorOptions.vue` y `src/components/ContadorComposition.vue`:
  el mismo componente (props, evento, estado, computed y ciclo de vida) en los
  dos estilos. El mensaje de `mounted` aparece en la consola del navegador.
- `src/composables/useMouse.js`: un composable que encapsula la posición del
  mouse. Lo usan `PosicionMouse.vue` y `CoordenadaX.vue`.

## Ejecutar

```sh
npm install
npm run dev
```

Documentación: https://vuejs.org/guide/extras/composition-api-faq.html
