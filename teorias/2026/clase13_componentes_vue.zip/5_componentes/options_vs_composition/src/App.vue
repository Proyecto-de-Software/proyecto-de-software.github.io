<script setup>
import { ref } from 'vue'
import ContadorOptions from './components/ContadorOptions.vue'
import ContadorComposition from './components/ContadorComposition.vue'
import PosicionMouse from './components/PosicionMouse.vue'
import CoordenadaX from './components/CoordenadaX.vue'

const ultimo = ref('ninguno')
</script>

<template>
  <h1>Options API vs Composition API</h1>

  <h2>El mismo componente en ambos estilos</h2>
  <ContadorOptions titulo="Options API" @cambio="(n) => (ultimo = `Options: ${n}`)" />
  <ContadorComposition titulo="Composition API" @cambio="(n) => (ultimo = `Composition: ${n}`)" />
  <p>Último evento recibido por el padre: {{ ultimo }}</p>

  <h2>Un composable usado por dos componentes</h2>
  <PosicionMouse />
  <CoordenadaX />
</template>
