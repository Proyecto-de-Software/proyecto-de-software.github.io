<script setup>
import { ref, computed, onMounted } from 'vue'

const props = defineProps(['titulo'])
const emit = defineEmits(['cambio'])

const count = ref(0)
const double = computed(() => count.value * 2)

function increment() {
  count.value++
  emit('cambio', count.value)
}

onMounted(() => {
  console.log(`${props.titulo}: montado`)
})
</script>

<template>
  <h3>{{ titulo }}</h3>
  <button @click="increment">count: {{ count }} · double: {{ double }}</button>
</template>
