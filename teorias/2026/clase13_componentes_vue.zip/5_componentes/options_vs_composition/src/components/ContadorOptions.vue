<script>
export default {
  props: ['titulo'],
  emits: ['cambio'],
  data() {
    return { count: 0 }
  },
  computed: {
    double() {
      return this.count * 2
    }
  },
  methods: {
    increment() {
      this.count++
      this.$emit('cambio', this.count)
    }
  },
  mounted() {
    console.log(`${this.titulo}: montado`)
  }
}
</script>

<template>
  <h3>{{ titulo }}</h3>
  <button @click="increment">count: {{ count }} · double: {{ double }}</button>
</template>
