<script setup>
import { computed } from 'vue'
import { useMouse } from '../composables/useMouse'

// Otro componente reutiliza la misma lógica y le agrega la suya.
const { x } = useMouse()
const lado = computed(() => (x.value < window.innerWidth / 2 ? 'izquierda' : 'derecha'))
</script>

<template>
  <p>Estás a la <strong>{{ lado }}</strong> de la pantalla</p>
</template>
