<script setup>
import { useMouse } from '../composables/useMouse'

const { x, y } = useMouse()
</script>

<template>
  <p>El mouse está en ({{ x }}, {{ y }})</p>
</template>
