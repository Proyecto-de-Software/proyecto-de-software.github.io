import { ref, onMounted, onUnmounted } from 'vue'

// Todo lo del mouse en un solo lugar: estado, listener y limpieza.
export function useMouse() {
  const x = ref(0)
  const y = ref(0)

  function actualizar(event) {
    x.value = event.pageX
    y.value = event.pageY
  }

  onMounted(() => window.addEventListener('mousemove', actualizar))
  onUnmounted(() => window.removeEventListener('mousemove', actualizar))

  return { x, y }
}
