# Vue Router

Ejemplo con Vite + Vue 3 + Vue Router. Muestra rutas simples, una ruta con
carga diferida (`/about`) y una ruta con nombre y parámetro (`/ruta2/:parametro`)
que se pasa al componente como prop.

## Ejecutar

```sh
npm install
npm run dev
```

## Build de producción

```sh
npm run build
npm run preview
```

Documentación: https://router.vuejs.org/
