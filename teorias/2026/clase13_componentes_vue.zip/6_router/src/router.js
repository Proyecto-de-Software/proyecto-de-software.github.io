import { createRouter, createWebHistory } from 'vue-router'
import Home from './views/Home.vue'
import Ruta1 from './views/Ruta1.vue'
import Ruta2 from './views/Ruta2.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: Home
  },
  {
    path: '/about',
    name: 'about',
    // Carga diferida: genera un archivo JS aparte (about.[hash].js)
    // que se descarga recién cuando se visita la ruta.
    component: () => import('./views/About.vue')
  },
  {
    path: '/ruta1',
    name: 'ruta1',
    component: Ruta1
  },
  {
    path: '/ruta2/:parametro',
    name: 'nombre-ruta2',
    component: Ruta2,
    props: true // pasa :parametro como prop al componente
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
