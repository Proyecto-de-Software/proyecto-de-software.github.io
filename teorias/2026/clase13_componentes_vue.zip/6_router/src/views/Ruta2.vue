<script setup>
// Recibe el parámetro de la ruta como prop (props: true en router.js)
defineProps({ parametro: String })
</script>

<template>
  <div class="ruta2">
    <h1>Ruta 2</h1>
    <h3>{{ parametro }}</h3>
  </div>
</template>
