# Pinia + Options API

Ejemplo con Vite + Vue 3 + Pinia usando **Options API**. El store se define como
options store (`state`, `actions`) y los componentes lo usan con los helpers
`mapState` (en `computed`) y `mapActions` (en `methods`).

## Ejecutar

```sh
npm install
npm run dev
```

## Build de producción

```sh
npm run build
npm run preview
```

Documentación: https://pinia.vuejs.org/cookbook/options-api.html
