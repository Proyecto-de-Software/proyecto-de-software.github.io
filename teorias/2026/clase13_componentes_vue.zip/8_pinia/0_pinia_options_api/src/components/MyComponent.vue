<script>
import { mapState, mapActions } from 'pinia'
import { useCounterPiniaStore } from '@/stores/test'

export default {
  computed: {
    // el estado (y los getters) van en computed
    ...mapState(useCounterPiniaStore, ['count']),
  },
  methods: {
    // las actions van en methods
    ...mapActions(useCounterPiniaStore, ['increment', 'randomizeCounter']),
  },
}
</script>

<template>
  <pre>Counter: {{ count }}</pre>
  <button @click="increment()">+</button>
  <button @click="randomizeCounter()">Randomize</button>
</template>
