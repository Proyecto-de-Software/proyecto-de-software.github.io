# Pinia + Composition API

Basado en el ejemplo oficial [piniajs/example-vue-3-vite](https://github.com/piniajs/example-vue-3-vite),
actualizado a Vue 3.5, Pinia 4 y Vite 8.

- `src/stores/user.js` y `src/stores/cart.js`: *option stores* (`state`, `getters`, `actions`).
- `src/App.vue` y `src/components/User.vue`: usan los stores con `<script setup>`.
- `src/components/About.vue`: usa el store desde Options API con `mapStores`.

## Ejecutar

```sh
npm install
npm run dev
```

Abrir http://localhost:5173 e inspeccionar los stores con las [Vue Devtools](https://devtools.vuejs.org/).
