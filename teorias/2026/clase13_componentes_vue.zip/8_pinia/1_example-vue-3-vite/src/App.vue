<script setup>
import { ref } from 'vue'
import Layout from './layouts/default.vue'
import PiniaLogo from './components/PiniaLogo.vue'
import About from './components/About.vue'
import User from './components/User.vue'
import { useUserStore } from './stores/user'
import { useCartStore } from './stores/cart'

const user = useUserStore()
const cart = useCartStore()

const itemName = ref('')

function addItemToCart() {
  if (!itemName.value) return
  cart.addItem(itemName.value)
  itemName.value = ''
}

function clearCart() {
  if (window.confirm('Are you sure you want to clear the cart?')) {
    cart.rawItems = []
  }
}

async function buy() {
  const n = await cart.purchaseItems()

  console.log(`Bought ${n} items`)

  cart.rawItems = []
}
</script>

<template>
  <Layout>
    <div>
      <div style="margin: 1rem 0;">
        <About />
      </div>
      <div style="margin: 1rem 0;">
        <User />
      </div>
      <div style="margin: 1rem 0;">
        <PiniaLogo />
      </div>

      <h2>Hello {{ user.name }}</h2>

      <form @submit.prevent="addItemToCart">
        <input type="text" v-model="itemName" />
        <button type="submit">Add</button>
      </form>

      <form @submit.prevent="buy">
        <ul>
          <li v-for="item in cart.items" :key="item.name">
            {{ item.name }} ({{ item.amount }})
            <button
              @click="cart.removeItem(item.name)"
              type="button"
            >X</button>
          </li>
        </ul>

        <button type="submit" :disabled="!user.name">Buy</button>
        <button
          :disabled="!cart.items.length"
          @click="clearCart"
          type="button"
        >Clear the cart</button>
      </form>
    </div>
  </Layout>
</template>

<style scoped>
img {
  width: 200px;
}

button,
input {
  margin-right: 0.5rem;
  margin-bottom: 0.5rem;
}
</style>
