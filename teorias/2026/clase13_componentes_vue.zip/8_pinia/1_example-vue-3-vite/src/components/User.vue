<script setup>
// Usando Composition API => https://vuejs.org/api/sfc-script-setup.html
import { useUserStore } from '../stores/user'

const user = useUserStore()
</script>

<template>
  <div>
    <h1>User</h1>
    <p>Usuario logueado: {{ user.name }} <span v-if="user.isAdmin">( Administrador!!! )</span></p>
  </div>
</template>
