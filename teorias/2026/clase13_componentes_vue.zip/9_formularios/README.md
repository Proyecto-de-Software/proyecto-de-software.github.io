# Formularios en Vue

Ejemplo con Vite + Vue 3. Al enviar un formulario válido, los datos se muestran
en la consola del navegador.

Sin librerías:

- `src/components/Inscripcion.vue`: `v-model` con distintos tipos de input.
- `src/components/InscripcionValidada.vue`: validación con `computed` y envío con
  axios. No hay backend, así que el `POST /api/inscripciones` responde 404 y se
  muestra el error del servidor.

El mismo formulario (nombre y email obligatorios) con una librería:

- `src/components/FormKitForm.vue`: [FormKit](https://formkit.com/) (el plugin se registra en `src/main.js`).

Los estilos de los errores (`.error` e `input[aria-invalid="true"]`) están en
`src/App.vue`.

## Ejecutar

```sh
npm install
npm run dev
```

## Build de producción

```sh
npm run build
npm run preview
```

Documentación: https://vuejs.org/guide/essentials/forms.html
