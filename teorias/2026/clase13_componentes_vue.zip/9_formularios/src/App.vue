<script setup>
import Inscripcion from './components/Inscripcion.vue'
import InscripcionValidada from './components/InscripcionValidada.vue'
import FormKitForm from './components/FormKitForm.vue'
import VeeForm from './components/VeeForm.vue'
import VuelidateForm from './components/VuelidateForm.vue'
</script>

<template>
  <div id="app">
    <h1>Formularios en Vue</h1>
    <p>Al enviar un formulario válido, los datos se muestran en la consola.</p>

    <h2>Sin librerías</h2>
    <div class="columnas">
      <section class="a-mano">
        <h3>Inscripcion.vue</h3>
        <Inscripcion />
      </section>
      <section class="a-mano">
        <h3>InscripcionValidada.vue</h3>
        <InscripcionValidada />
      </section>
    </div>

    <h2>Con librerías: el mismo formulario</h2>
    <div class="columnas">
      <section>
        <h3>FormKit</h3>
        <FormKitForm />
      </section>
      <section class="a-mano">
        <h3>VeeValidate</h3>
        <VeeForm />
      </section>
      <section class="a-mano">
        <h3>Vuelidate</h3>
        <VuelidateForm />
      </section>
    </div>
  </div>
</template>

<style>
/* Estilos de validación: los usan los formularios hechos sin FormKit. */
.error {
  color: #c0392b;
  font-size: 0.9em;
}
input[aria-invalid="true"] {
  border-color: #c0392b;
  outline-color: #c0392b;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin: 40px auto;
  max-width: 1000px;
}
h1, #app > p {
  text-align: center;
}
h2 {
  margin-top: 40px;
  border-bottom: 1px solid #ddd;
}
.columnas {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 32px;
}
/* Sólo para los formularios hechos a mano: FormKit trae sus propios estilos. */
.a-mano input:not([type="checkbox"]),
.a-mano select {
  display: block;
  box-sizing: border-box;
  width: 100%;
  padding: 8px;
  margin-top: 12px;
}
.a-mano label {
  display: block;
  margin-top: 12px;
}
.a-mano .error {
  margin: 4px 0 0;
}
.a-mano button {
  margin-top: 12px;
  padding: 8px 16px;
}
</style>
