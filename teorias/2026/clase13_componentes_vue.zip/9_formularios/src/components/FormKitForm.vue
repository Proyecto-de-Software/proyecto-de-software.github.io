<script setup>
function enviar(datos) {
  console.log(datos) // { nombre, email }
}
</script>

<template>
  <FormKit type="form" submit-label="Enviar"
           @submit="enviar">
    <FormKit type="text" name="nombre"
             label="Nombre" validation="required" />
    <FormKit type="email" name="email"
             label="Email" validation="required|email" />
  </FormKit>
</template>
