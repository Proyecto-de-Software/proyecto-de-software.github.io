<script setup>
import { reactive } from 'vue'

const form = reactive({ nombre: '', edad: null, carrera: '', acepta: false })

function enviar() {
  console.log({ ...form })
}
</script>

<template>
  <form @submit.prevent="enviar">
    <input v-model.trim="form.nombre" placeholder="Nombre">
    <input v-model.number="form.edad" type="number" placeholder="Edad">
    <select v-model="form.carrera">
      <option disabled value="">Elegí una carrera</option>
      <option>Licenciatura en Sistemas</option>
      <option>Licenciatura en Informática</option>
    </select>
    <label><input v-model="form.acepta" type="checkbox"> Acepto los términos</label>
    <button>Enviar</button>
  </form>
</template>
