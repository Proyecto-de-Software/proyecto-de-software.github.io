<script setup>
import { reactive, ref, computed } from 'vue'
import axios from 'axios'

const form = reactive({ nombre: '', email: '' })
const enviando = ref(false)
const errorServidor = ref('')

// Los errores se recalculan solos cada vez que cambia el formulario.
const errores = computed(() => ({
  nombre: form.nombre ? '' : 'El nombre es obligatorio',
  email: /^\S+@\S+\.\S+$/.test(form.email) ? '' : 'Email inválido',
}))
const valido = computed(() => !errores.value.nombre && !errores.value.email)

async function enviar() {
  enviando.value = true
  errorServidor.value = ''
  try {
    await axios.post('/api/inscripciones', form)
  } catch (e) {
    errorServidor.value = e.response?.data?.error ?? e.message
  } finally {
    enviando.value = false
  }
}
</script>

<template>
  <form @submit.prevent="enviar">
    <input v-model.trim="form.nombre" placeholder="Nombre"
           :aria-invalid="!!errores.nombre">
    <p v-if="errores.nombre" class="error">{{ errores.nombre }}</p>

    <input v-model.trim="form.email" placeholder="Email"
           :aria-invalid="!!errores.email">
    <p v-if="errores.email" class="error">{{ errores.email }}</p>

    <button type="submit" :disabled="!valido || enviando">
      {{ enviando ? 'Enviando...' : 'Enviar' }}
    </button>
    <p v-if="errorServidor" class="error">{{ errorServidor }}</p>
  </form>
</template>
