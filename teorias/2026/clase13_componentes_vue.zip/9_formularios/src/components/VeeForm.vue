<script setup>
import { useForm } from 'vee-validate'

const { defineField, handleSubmit, errors } = useForm({
  validationSchema: {
    nombre: (v) => !!v || 'El nombre es obligatorio',
    email: (v) => /^\S+@\S+\.\S+$/.test(v ?? '') || 'Email inválido',
  },
})
const [nombre] = defineField('nombre')
const [email] = defineField('email')

const enviar = handleSubmit((datos) => console.log(datos))
</script>

<template>
  <form @submit="enviar">
    <input v-model="nombre" placeholder="Nombre"
           :aria-invalid="!!errors.nombre">
    <p class="error">{{ errors.nombre }}</p>
    <input v-model="email" placeholder="Email"
           :aria-invalid="!!errors.email">
    <p class="error">{{ errors.email }}</p>
    <button>Enviar</button>
  </form>
</template>
