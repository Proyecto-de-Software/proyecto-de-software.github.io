<script setup>
import { reactive } from 'vue'
import { useVuelidate } from '@vuelidate/core'
import { required, email, helpers } from '@vuelidate/validators'

const form = reactive({ nombre: '', email: '' })
const reglas = {
  nombre: { required: helpers.withMessage('Obligatorio', required) },
  email: {
    required: helpers.withMessage('Obligatorio', required),
    email: helpers.withMessage('Email inválido', email),
  },
}
const v$ = useVuelidate(reglas, form)

async function enviar() {
  if (await v$.value.$validate()) console.log({ ...form })
}
</script>

<template>
  <form @submit.prevent="enviar">
    <input v-model="form.nombre" placeholder="Nombre"
           :aria-invalid="v$.nombre.$error">
    <p v-if="v$.nombre.$error" class="error">
      {{ v$.nombre.$errors[0].$message }}
    </p>
    <input v-model="form.email" placeholder="Email"
           :aria-invalid="v$.email.$error">
    <p v-if="v$.email.$error" class="error">
      {{ v$.email.$errors[0].$message }}
    </p>
    <button>Enviar</button>
  </form>
</template>
