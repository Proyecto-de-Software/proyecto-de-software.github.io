import { createApp } from 'vue'
import { plugin, defaultConfig } from '@formkit/vue'
import { es } from '@formkit/i18n'
import '@formkit/themes/genesis'
import App from './App.vue'

createApp(App)
  .use(plugin, defaultConfig({ locales: { es }, locale: 'es' }))
  .mount('#app')
