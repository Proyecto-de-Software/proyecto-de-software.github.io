from src.core.database import db
from src.core.auth.user import User
# SQLi
from sqlalchemy import text
from marshmallow import Schema, fields


class UserSchema(Schema):
    id = fields.Integer()
    email = fields.Str()
    name = fields.Str()
    
def list_users():
    return User.query.all()


def create_user(**kwargs):
    user = User(**kwargs)
    db.session.add(user)
    db.session.commit()

    return user


def get_user_by_id(id):
    
    user = User.query.get(id)
    schema = UserSchema()  
    return schema.dump(user)

def find_user_by_email_and_pass(email, password):
    return User.query.filter(User.email == email, User.password == password).first()


def find_user_by_email(email):
    return User.query.filter(User.email == email).first()

# SQLi
def find_user_by_email_and_pass_sqli(email, password):
    sql = text("SELECT * from users WHERE email = '"+email+"' AND password = '"+password+"'")
    return db.engine.execute(sql).first()